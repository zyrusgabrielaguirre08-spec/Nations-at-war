package com.example.nationsatwar.war;

import com.example.nationsatwar.NationsAtWarMod;
import com.example.nationsatwar.NationsConfig;
import com.example.nationsatwar.data.Nation;
import com.example.nationsatwar.data.NationDataManager;
import com.example.nationsatwar.data.NationDataManager.NationException;
import com.example.nationsatwar.data.PlayerData;
import com.example.nationsatwar.data.War;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * War state machine: PENDING (warning countdown) -> ACTIVE -> resolved (war removed).
 * Wall-clock based, so the countdown also elapses while the server is offline.
 */
public final class WarManager {
    private static final Logger LOGGER = LogManager.getLogger("NationsAtWar/War");

    private final NationDataManager data;

    public WarManager(NationDataManager data) {
        this.data = data;
    }

    private static NationsConfig cfg() { return NationsAtWarMod.config(); }

    // ------------------------------------------------------------------ queries

    /** Any war (pending or active) between the two nations. */
    @Nullable
    public War findWar(UUID a, UUID b) {
        for (War w : data.wars()) if (w.isBetween(a, b)) return w;
        return null;
    }

    public boolean isActiveWar(UUID a, UUID b) {
        War w = findWar(a, b);
        return w != null && w.state == War.State.ACTIVE;
    }

    @Nullable
    private War findActiveWarOf(UUID nation) {
        for (War w : data.wars()) if (w.involves(nation) && w.state == War.State.ACTIVE) return w;
        return null;
    }

    public List<War> warsOf(UUID nation) {
        List<War> out = new ArrayList<>();
        for (War w : data.wars()) if (w.involves(nation)) out.add(w);
        return out;
    }

    // ------------------------------------------------------------------ /nation enemy

    /**
     * Toggles enmity. Declaring starts the warning countdown; toggling again while the war is still PENDING
     * (and you are the declarer) withdraws the declaration. Active wars end only by victory or surrender.
     */
    public String toggleEnemy(ServerPlayer p, String targetName) throws NationException {
        Nation me = data.requireNationOf(p);
        data.requireOwner(me, p);
        Nation target = data.requireNationByName(targetName);
        if (me == target) throw new NationException("You can't declare war on yourself.");

        War existing = findWar(me.id, target.id);
        if (existing != null) {
            if (existing.state == War.State.ACTIVE) {
                throw new NationException("The war is already active. Win it, or use /nation surrender.");
            }
            if (!existing.attacker.equals(me.id)) {
                throw new NationException(target.name + " has already declared war on you. It starts in "
                        + formatDuration(existing.startsAtMs - System.currentTimeMillis()) + ".");
            }
            data.wars().remove(existing);
            me.enemies.remove(target.name);
            target.enemies.remove(me.name);
            data.markDirty();
            data.broadcastAll(Component.literal(me.name + " has withdrawn its war declaration against " + target.name + ".")
                    .withStyle(ChatFormatting.YELLOW));
            return "War declaration withdrawn.";
        }

        if (me.allies.contains(target.name)) throw new NationException("Dissolve your alliance with " + target.name + " first.");

        long now = System.currentTimeMillis();
        War w = new War(me.id, target.id, now, now + cfg().warWarningSeconds * 1000L);
        data.wars().add(w);
        me.enemies.add(target.name);
        target.enemies.add(me.name);
        data.markDirty();
        data.broadcastAll(Component.literal("\u2694 " + me.name + " has declared war on " + target.name + "! Fighting begins in "
                + formatDuration(cfg().warWarningSeconds * 1000L) + ".").withStyle(ChatFormatting.RED));
        LOGGER.info("War declared: {} -> {}", me.name, target.name);
        return "War declared on " + target.name + ". It becomes active in " + formatDuration(cfg().warWarningSeconds * 1000L) + ".";
    }

    // ------------------------------------------------------------------ ticking

    /** Called once per second from the server tick. */
    public void tick() {
        if (data.wars().isEmpty()) return;
        long now = System.currentTimeMillis();
        for (War w : new ArrayList<>(data.wars())) {
            if (w.state == War.State.PENDING && now >= w.startsAtMs) {
                Nation a = data.getNation(w.attacker);
                Nation d = data.getNation(w.defender);
                if (a == null || d == null) {
                    data.wars().remove(w);
                    continue;
                }
                w.state = War.State.ACTIVE;
                data.markDirty();
                data.broadcastAll(Component.literal("\u2694 WAR HAS BEGUN: " + a.name + " vs " + d.name
                        + "! First to " + cfg().warScoreToWin + " kills, or a captured banner, wins.").withStyle(ChatFormatting.DARK_RED));
            }
        }
    }

    // ------------------------------------------------------------------ scoring & victory

    public void onPlayerKill(ServerPlayer killer, ServerPlayer victim) {
        Nation kn = data.getNationOf(killer.getUUID());
        Nation vn = data.getNationOf(victim.getUUID());
        if (kn == null || vn == null || kn == vn) return;
        War w = findWar(kn.id, vn.id);
        if (w == null || w.state != War.State.ACTIVE) return;

        if (w.attacker.equals(kn.id)) w.attackerScore++;
        else w.defenderScore++;
        data.getPlayerData(killer.getUUID()).contributionPoints++;
        data.markDirty();

        int ks = w.attacker.equals(kn.id) ? w.attackerScore : w.defenderScore;
        Component msg = Component.literal("\u2694 " + killer.getGameProfile().getName() + " (" + kn.name + ") killed "
                + victim.getGameProfile().getName() + " (" + vn.name + "). Score: " + ks + "/" + cfg().warScoreToWin)
                .withStyle(ChatFormatting.GOLD);
        data.broadcast(kn, msg);
        data.broadcast(vn, msg);

        if (ks >= cfg().warScoreToWin) resolve(w, kn, vn, "reached the kill target");
    }

    /**
     * Called by the protection listener when a banner is broken during an active war.
     * @return true if the break was handled as a capture (caller should cancel the vanilla break)
     */
    public boolean tryCaptureBanner(ServerPlayer breaker, Nation breakerNation, Nation bannerOwner, BlockPos pos) {
        if (bannerOwner.bannerPos == null || bannerOwner.bannerPos != pos.asLong()) return false;
        War w = findWar(breakerNation.id, bannerOwner.id);
        if (w == null || w.state != War.State.ACTIVE) return false;
        PlayerData pd = data.getPlayerData(breaker.getUUID());
        pd.contributionPoints += cfg().bannerCaptureContributionPoints;
        resolve(w, breakerNation, bannerOwner, "captured the banner");
        return true;
    }

    public void surrender(ServerPlayer p) throws NationException {
        Nation me = data.requireNationOf(p);
        data.requireOwner(me, p);
        War w = findActiveWarOf(me.id);
        if (w == null) throw new NationException("Your nation has no active war to surrender in.");
        Nation winner = data.getNation(w.other(me.id));
        if (winner == null) throw new NationException("The opposing nation no longer exists.");
        resolve(w, winner, me, "accepted the surrender of");
    }

    /** Admin: cancel a war without a winner or reparations. */
    public void adminEndWar(Nation a, Nation b) throws NationException {
        War w = findWar(a.id, b.id);
        if (w == null) throw new NationException("There is no war between those nations.");
        data.wars().remove(w);
        a.enemies.remove(b.name);
        b.enemies.remove(a.name);
        data.markDirty();
        data.broadcastAll(Component.literal("The war between " + a.name + " and " + b.name + " was ended by an administrator.")
                .withStyle(ChatFormatting.YELLOW));
    }

    private void resolve(War w, Nation winner, Nation loser, String how) {
        data.wars().remove(w);
        winner.enemies.remove(loser.name);
        loser.enemies.remove(winner.name);

        double loot = NationDataManager.round2(loser.balance * cfg().warLootPercent / 100.0);
        loser.balance = NationDataManager.round2(loser.balance - loot);
        winner.balance = NationDataManager.round2(winner.balance + loot);
        int moved = transferChunks(winner, loser, cfg().warSurrenderChunks);
        data.markDirty();

        data.broadcastAll(Component.literal("\u2694 " + winner.name + " has defeated " + loser.name + " (" + how + "). "
                + "Reparations: " + NationDataManager.money(loot) + " and " + moved + " chunk(s).").withStyle(ChatFormatting.GREEN));
        LOGGER.info("War resolved: {} beat {} ({}), loot={}, chunks={}", winner.name, loser.name, how, loot, moved);
    }

    /** The loser forfeits the chunks closest to the winner's territory centre. */
    private int transferChunks(Nation winner, Nation loser, int count) {
        if (count <= 0 || loser.claimedChunks.isEmpty()) return 0;
        Collection<ChunkPos> ref = winner.claimedChunks.isEmpty() ? loser.claimedChunks : winner.claimedChunks;
        double sx = 0, sz = 0;
        for (ChunkPos c : ref) {
            sx += c.x;
            sz += c.z;
        }
        final double cx = sx / ref.size();
        final double cz = sz / ref.size();
        List<ChunkPos> sorted = new ArrayList<>(loser.claimedChunks);
        sorted.sort(Comparator.comparingDouble(c -> (c.x - cx) * (c.x - cx) + (c.z - cz) * (c.z - cz)));
        int moved = 0;
        for (ChunkPos c : sorted) {
            if (moved >= count) break;
            data.transferChunk(c, loser, winner);
            moved++;
        }
        return moved;
    }

    public static String formatDuration(long ms) {
        long s = Math.max(0, ms / 1000);
        long h = s / 3600;
        long m = (s % 3600) / 60;
        if (h > 0) return h + "h " + m + "m";
        if (m > 0) return m + "m " + (s % 60) + "s";
        return s + "s";
    }
}
