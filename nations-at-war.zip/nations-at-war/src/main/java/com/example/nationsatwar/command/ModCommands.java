package com.example.nationsatwar.command;

import com.example.nationsatwar.NationsAtWarMod;
import com.example.nationsatwar.NationsConfig;
import com.example.nationsatwar.data.Nation;
import com.example.nationsatwar.data.NationDataManager;
import com.example.nationsatwar.data.NationDataManager.NationException;
import com.example.nationsatwar.data.War;
import com.example.nationsatwar.war.WarManager;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.example.nationsatwar.data.NationDataManager.money;

/**
 * Brigadier tree for /nation. Permission model: everything is level 0 (everyone) except
 * /nation admin ..., which requires level 2. Expected failures are thrown as NationException and
 * converted into a red chat message by {@link #exec}.
 */
public final class ModCommands {
    private ModCommands() {}

    @FunctionalInterface
    private interface Action {
        int run(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException;
    }

    private static Command<CommandSourceStack> exec(Action action) {
        return ctx -> {
            try {
                return action.run(ctx);
            } catch (NationException e) {
                ctx.getSource().sendFailure(Component.literal(e.getMessage()));
                return 0;
            }
        };
    }

    private static final SuggestionProvider<CommandSourceStack> NATION_NAMES = (ctx, builder) -> {
        NationDataManager d = NationDataManager.get();
        return SharedSuggestionProvider.suggest(d == null ? List.<String>of() : d.nationNames(), builder);
    };

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("nation")
                .then(Commands.literal("create")
                        .then(Commands.argument("name", StringArgumentType.word()).executes(exec(ModCommands::create))))
                .then(Commands.literal("join")
                        .then(Commands.argument("name", StringArgumentType.word()).suggests(NATION_NAMES).executes(exec(ModCommands::join))))
                .then(Commands.literal("leave").executes(exec(ModCommands::leave)))
                .then(Commands.literal("disband").executes(exec(ModCommands::disband)))
                .then(Commands.literal("invite")
                        .then(Commands.argument("player", EntityArgument.player()).executes(exec(ModCommands::invite))))
                .then(Commands.literal("claim").executes(exec(ModCommands::claim)))
                .then(Commands.literal("unclaim").executes(exec(ModCommands::unclaim)))
                .then(Commands.literal("setbanner").executes(exec(ModCommands::setBanner)))
                .then(Commands.literal("ally")
                        .then(Commands.argument("nation_name", StringArgumentType.word()).suggests(NATION_NAMES).executes(exec(ModCommands::ally))))
                .then(Commands.literal("enemy")
                        .then(Commands.argument("nation_name", StringArgumentType.word()).suggests(NATION_NAMES).executes(exec(ModCommands::enemy))))
                .then(Commands.literal("surrender").executes(exec(ModCommands::surrender)))
                .then(Commands.literal("deposit")
                        .then(Commands.argument("amount", DoubleArgumentType.doubleArg(0.01)).executes(exec(ModCommands::deposit))))
                .then(Commands.literal("withdraw")
                        .then(Commands.argument("amount", DoubleArgumentType.doubleArg(0.01)).executes(exec(ModCommands::withdraw))))
                .then(Commands.literal("info")
                        .executes(exec(ctx -> info(ctx, null)))
                        .then(Commands.argument("name", StringArgumentType.word()).suggests(NATION_NAMES)
                                .executes(exec(ctx -> info(ctx, StringArgumentType.getString(ctx, "name"))))))
                .then(Commands.literal("admin")
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.literal("bypass").executes(exec(ModCommands::adminBypass)))
                        .then(Commands.literal("reload").executes(exec(ModCommands::adminReload)))
                        .then(Commands.literal("give")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .then(Commands.argument("amount", DoubleArgumentType.doubleArg(0.01)).executes(exec(ModCommands::adminGive)))))
                        .then(Commands.literal("disband")
                                .then(Commands.argument("nation_name", StringArgumentType.word()).suggests(NATION_NAMES).executes(exec(ModCommands::adminDisband))))
                        .then(Commands.literal("endwar")
                                .then(Commands.argument("nation_a", StringArgumentType.word()).suggests(NATION_NAMES)
                                        .then(Commands.argument("nation_b", StringArgumentType.word()).suggests(NATION_NAMES)
                                                .executes(exec(ModCommands::adminEndWar)))))));
    }

    // ================================================================== helpers

    private static NationDataManager data() throws NationException {
        NationDataManager d = NationDataManager.get();
        if (d == null) throw new NationException("Nation data is not loaded yet.");
        return d;
    }

    private static void ok(CommandContext<CommandSourceStack> ctx, String msg) {
        ctx.getSource().sendSuccess(() -> Component.literal(msg).withStyle(ChatFormatting.GREEN), false);
    }

    // ================================================================== player commands

    private static int create(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        NationDataManager d = data();
        Nation n = d.createNation(p, StringArgumentType.getString(ctx, "name"));
        d.broadcastAll(Component.literal("\u2691 " + p.getGameProfile().getName() + " founded the nation of " + n.name + "!")
                .withStyle(ChatFormatting.GOLD));
        ok(ctx, "Nation founded. Fee paid: " + money(NationsAtWarMod.config().creationFee) + ". Next: /nation claim");
        return 1;
    }

    private static int join(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        NationDataManager d = data();
        Nation n = d.join(p, StringArgumentType.getString(ctx, "name"));
        d.broadcast(n, Component.literal(p.getGameProfile().getName() + " joined " + n.name + ".").withStyle(ChatFormatting.GREEN));
        return 1;
    }

    private static int leave(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        NationDataManager d = data();
        Nation n = d.requireNationOf(p);
        d.leave(p);
        d.broadcast(n, Component.literal(p.getGameProfile().getName() + " left the nation.").withStyle(ChatFormatting.YELLOW));
        ok(ctx, "You left " + n.name + ".");
        return 1;
    }

    private static int disband(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        NationDataManager d = data();
        Nation n = d.requireNationOf(p);
        d.requireOwner(n, p);
        d.disbandNation(n, true);
        d.broadcastAll(Component.literal("The nation of " + n.name + " has been disbanded.").withStyle(ChatFormatting.GOLD));
        ok(ctx, "Nation disbanded. The bank balance was refunded to your wallet.");
        return 1;
    }

    private static int invite(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
        NationDataManager d = data();
        d.invite(p, target);
        Nation n = d.requireNationOf(p);
        target.sendSystemMessage(Component.literal("You have been invited to " + n.name + ". Use /nation join " + n.name
                + " within " + NationsAtWarMod.config().inviteExpirySeconds + "s.").withStyle(ChatFormatting.AQUA));
        ok(ctx, "Invited " + target.getGameProfile().getName() + ".");
        return 1;
    }

    private static int claim(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        NationDataManager d = data();
        ChunkPos cp = new ChunkPos(p.blockPosition());
        d.claimChunk(p, cp);
        Nation n = d.requireNationOf(p);
        ok(ctx, "Claimed chunk [" + cp.x + ", " + cp.z + "] (" + n.claimedChunks.size() + "/" + d.maxClaims(n) + ").");
        return 1;
    }

    private static int unclaim(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        ChunkPos cp = new ChunkPos(p.blockPosition());
        data().unclaimChunk(p, cp);
        ok(ctx, "Unclaimed chunk [" + cp.x + ", " + cp.z + "].");
        return 1;
    }

    private static int setBanner(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        HitResult hit = p.pick(5.0, 0.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) throw new NationException("Look at a banner block (within 5 blocks).");
        data().setBanner(p, ((BlockHitResult) hit).getBlockPos());
        ok(ctx, "Banner registered. Enemies who break it during a war win the siege - defend it!");
        return 1;
    }

    private static int ally(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        NationDataManager d = data();
        String target = StringArgumentType.getString(ctx, "nation_name");
        boolean allied = d.toggleAlly(p, target);
        Nation me = d.requireNationOf(p);
        Nation other = d.requireNationByName(target);
        Component msg = Component.literal(allied
                ? me.name + " and " + other.name + " are now allies."
                : "The alliance between " + me.name + " and " + other.name + " has ended.").withStyle(ChatFormatting.AQUA);
        d.broadcast(me, msg);
        d.broadcast(other, msg);
        return 1;
    }

    private static int enemy(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        ok(ctx, data().warManager().toggleEnemy(p, StringArgumentType.getString(ctx, "nation_name")));
        return 1;
    }

    private static int surrender(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        data().warManager().surrender(ctx.getSource().getPlayerOrException());
        return 1;
    }

    private static int deposit(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        double amt = DoubleArgumentType.getDouble(ctx, "amount");
        NationDataManager d = data();
        d.deposit(p, amt);
        ok(ctx, "Deposited " + money(amt) + ". Nation bank: " + money(d.requireNationOf(p).balance)
                + " | Your wallet: " + money(d.getPlayerData(p.getUUID()).balance));
        return 1;
    }

    private static int withdraw(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        double amt = DoubleArgumentType.getDouble(ctx, "amount");
        NationDataManager d = data();
        d.withdraw(p, amt);
        ok(ctx, "Withdrew " + money(amt) + ". Nation bank: " + money(d.requireNationOf(p).balance)
                + " | Your wallet: " + money(d.getPlayerData(p.getUUID()).balance));
        return 1;
    }

    private static int info(CommandContext<CommandSourceStack> ctx, String name) throws NationException, CommandSyntaxException {
        NationDataManager d = data();
        Nation n;
        if (name == null) {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            n = d.getNationOf(p.getUUID());
            if (n == null) {
                ok(ctx, "You are not in a nation. Wallet: " + money(d.getPlayerData(p.getUUID()).balance)
                        + " (founding costs " + money(NationsAtWarMod.config().creationFee) + ").");
                return 1;
            }
        } else {
            n = d.requireNationByName(name);
        }

        List<String> memberNames = new ArrayList<>();
        for (UUID m : n.members) memberNames.add(d.nameOf(m));
        List<String> lines = new ArrayList<>();
        lines.add("=== " + n.name + " ===");
        lines.add("Owner: " + d.nameOf(n.owner) + " | Members (" + n.members.size() + "): " + String.join(", ", memberNames));
        lines.add("Claims: " + n.claimedChunks.size() + "/" + d.maxClaims(n) + " | Bank: " + money(n.balance)
                + " | Banner: " + (n.bannerPos == null ? "not set" : "set"));
        lines.add("Allies: " + (n.allies.isEmpty() ? "none" : String.join(", ", n.allies)));
        lines.add("Enemies: " + (n.enemies.isEmpty() ? "none" : String.join(", ", n.enemies)));
        for (War w : d.warManager().warsOf(n.id)) {
            Nation a = d.getNation(w.attacker);
            Nation df = d.getNation(w.defender);
            if (a == null || df == null) continue;
            lines.add(w.state == War.State.PENDING
                    ? "War: " + a.name + " -> " + df.name + " starts in " + WarManager.formatDuration(w.startsAtMs - System.currentTimeMillis())
                    : "War: " + a.name + " " + w.attackerScore + " - " + w.defenderScore + " " + df.name
                    + " (first to " + NationsAtWarMod.config().warScoreToWin + ")");
        }
        for (String l : lines) ctx.getSource().sendSuccess(() -> Component.literal(l).withStyle(ChatFormatting.GRAY), false);
        return 1;
    }

    // ================================================================== admin (permission level 2)

    private static int adminBypass(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        ok(ctx, "Claim bypass " + (data().toggleBypass(p.getUUID()) ? "ENABLED" : "disabled") + ".");
        return 1;
    }

    private static int adminReload(CommandContext<CommandSourceStack> ctx) {
        NationsAtWarMod.reloadConfig();
        ok(ctx, "Config reloaded.");
        return 1;
    }

    private static int adminGive(CommandContext<CommandSourceStack> ctx) throws NationException, CommandSyntaxException {
        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
        double amt = DoubleArgumentType.getDouble(ctx, "amount");
        data().giveMoney(target.getUUID(), amt);
        ok(ctx, "Gave " + money(amt) + " to " + target.getGameProfile().getName() + ".");
        return 1;
    }

    private static int adminDisband(CommandContext<CommandSourceStack> ctx) throws NationException {
        NationDataManager d = data();
        Nation n = d.requireNationByName(StringArgumentType.getString(ctx, "nation_name"));
        d.disbandNation(n, true);
        d.broadcastAll(Component.literal("The nation of " + n.name + " was disbanded by an administrator.").withStyle(ChatFormatting.GOLD));
        return 1;
    }

    private static int adminEndWar(CommandContext<CommandSourceStack> ctx) throws NationException {
        NationDataManager d = data();
        Nation a = d.requireNationByName(StringArgumentType.getString(ctx, "nation_a"));
        Nation b = d.requireNationByName(StringArgumentType.getString(ctx, "nation_b"));
        d.warManager().adminEndWar(a, b);
        return 1;
    }
}
