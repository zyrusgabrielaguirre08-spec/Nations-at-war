package com.example.nationsatwar.data;

import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/** Per-player record: nation affiliation, war contribution and personal wallet. */
public final class PlayerData {
    @Nullable
    public UUID nationId;
    public int contributionPoints;
    /** Personal wallet used for the creation fee and deposits. */
    public double balance;
    public String lastKnownName = "";
}
