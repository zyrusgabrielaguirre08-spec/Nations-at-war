package com.example.nationsatwar;

import com.example.nationsatwar.command.ModCommands;
import com.example.nationsatwar.data.NationDataManager;
import com.example.nationsatwar.protection.ProtectionListener;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;

/** Entry point: config, lifecycle (load/save), tick hooks, commands and protection listeners. */
public class NationsAtWarMod implements ModInitializer {
    public static final String MOD_ID = "nations_at_war";
    private static final Logger LOGGER = LogManager.getLogger("NationsAtWar");
    private static final int AUTOSAVE_INTERVAL_TICKS = 20 * 60 * 5; // 5 minutes, only writes if something changed

    private static NationsConfig config = new NationsConfig();

    /** Always read the config through this getter so {@code /nation admin reload} takes effect everywhere. */
    public static NationsConfig config() { return config; }

    public static void reloadConfig() {
        config = NationsConfig.loadOrCreate(configPath());
    }

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + ".json");
    }

    @Override
    public void onInitialize() {
        reloadConfig();

        ServerLifecycleEvents.SERVER_STARTING.register(NationDataManager::init);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            NationDataManager d = NationDataManager.get();
            if (d != null) d.save();
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> NationDataManager.release());

        ServerTickEvents.END_SERVER_TICK.register(NationsAtWarMod::onServerTick);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            NationDataManager d = NationDataManager.get();
            if (d != null) d.touchPlayer(handler.player);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> ModCommands.register(dispatcher));
        ProtectionListener.register();

        LOGGER.info("Nations At War initialised.");
    }

    private static void onServerTick(MinecraftServer server) {
        NationDataManager d = NationDataManager.get();
        if (d == null) return;
        int t = server.getTickCount();
        if (t % 20 == 0) d.warManager().tick();
        if (t % AUTOSAVE_INTERVAL_TICKS == 0) d.saveIfDirty();
    }
}
