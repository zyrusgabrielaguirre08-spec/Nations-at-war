package com.example.nationsatwar;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** JSON config at config/nations_at_war.json. Written back on every load so new options appear automatically. */
public final class NationsConfig {
    private static final Logger LOGGER = LogManager.getLogger("NationsAtWar/Config");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // ---- economy ----
    public double startingBalance = 5000.0;
    public double creationFee = 1000.0;

    // ---- nations & claims ----
    public int minNameLength = 3;
    public int maxNameLength = 20;
    public int baseMaxClaims = 6;
    public int extraClaimsPerMember = 3;
    public boolean requireAdjacentClaims = true;
    public int inviteExpirySeconds = 300;
    /** If true, allied nations get the same build/interact rights as members. */
    public boolean alliesCanInteract = false;

    // ---- combat ----
    public boolean friendlyFire = false;
    /** If true, players may only damage each other while their nations are in an ACTIVE war. */
    public boolean pvpOnlyBetweenWarringNations = false;

    // ---- war ----
    public long warWarningSeconds = 86_400;
    public int warScoreToWin = 10;
    public int bannerCaptureContributionPoints = 5;
    public double warLootPercent = 20.0;
    public int warSurrenderChunks = 2;
    public boolean warAllowSiegeBreaking = true;
    public boolean warExplosionsEnabled = true;
    public boolean warAllowSwitchInteraction = true;
    public boolean warAllowContainerAccess = false;

    /** Blocks attackers may remove (without drops) inside enemy claims. "#ns:tag" entries are block tags. */
    public List<String> siegeBreakableBlocks = new ArrayList<>(List.of(
            "#minecraft:doors", "#minecraft:wooden_trapdoors", "#minecraft:fence_gates", "#minecraft:fences",
            "#minecraft:leaves", "minecraft:glass", "minecraft:glass_pane",
            "minecraft:cracked_stone_bricks", "minecraft:cracked_deepslate_bricks", "minecraft:cracked_deepslate_tiles",
            "minecraft:cracked_nether_bricks", "minecraft:cracked_polished_blackstone_bricks"));

    /** Blocks attackers may place inside enemy claims (siege equipment). */
    public List<String> siegePlaceableBlocks = new ArrayList<>(List.of(
            "minecraft:tnt", "minecraft:ladder", "minecraft:scaffolding"));

    /** Breaking key turns it into value instead of destroying it ("cracking"). */
    public Map<String, String> crackedConversions = new LinkedHashMap<>(defaultCracked());

    private transient BlockMatcher breakable = new BlockMatcher();
    private transient BlockMatcher placeable = new BlockMatcher();
    private transient Map<Block, Block> cracked = new HashMap<>();

    private static Map<String, String> defaultCracked() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("minecraft:stone_bricks", "minecraft:cracked_stone_bricks");
        m.put("minecraft:deepslate_bricks", "minecraft:cracked_deepslate_bricks");
        m.put("minecraft:deepslate_tiles", "minecraft:cracked_deepslate_tiles");
        m.put("minecraft:nether_bricks", "minecraft:cracked_nether_bricks");
        m.put("minecraft:polished_blackstone_bricks", "minecraft:cracked_polished_blackstone_bricks");
        return m;
    }

    public boolean isSiegeBreakable(BlockState s) { return breakable.matches(s); }
    public boolean isSiegePlaceable(BlockState s) { return placeable.matches(s); }

    @Nullable
    public Block crackedVariantOf(Block b) { return cracked.get(b); }

    // ------------------------------------------------------------------ loading

    public static NationsConfig loadOrCreate(Path path) {
        NationsConfig cfg = new NationsConfig();
        if (Files.exists(path)) {
            try (Reader r = Files.newBufferedReader(path)) {
                NationsConfig read = GSON.fromJson(r, NationsConfig.class);
                if (read != null) cfg = read;
            } catch (IOException | JsonParseException e) {
                LOGGER.error("Could not read {}, falling back to defaults", path, e);
            }
        }
        cfg.sanitize();
        cfg.compile();
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, GSON.toJson(cfg));
        } catch (IOException e) {
            LOGGER.error("Could not write {}", path, e);
        }
        return cfg;
    }

    private void sanitize() {
        creationFee = Math.max(0, creationFee);
        startingBalance = Math.max(0, startingBalance);
        minNameLength = Math.max(1, minNameLength);
        maxNameLength = Math.max(minNameLength, maxNameLength);
        baseMaxClaims = Math.max(0, baseMaxClaims);
        extraClaimsPerMember = Math.max(0, extraClaimsPerMember);
        warWarningSeconds = Math.max(0, warWarningSeconds);
        warScoreToWin = Math.max(1, warScoreToWin);
        warLootPercent = Math.max(0, Math.min(100, warLootPercent));
        warSurrenderChunks = Math.max(0, warSurrenderChunks);
        if (siegeBreakableBlocks == null) siegeBreakableBlocks = new ArrayList<>();
        if (siegePlaceableBlocks == null) siegePlaceableBlocks = new ArrayList<>();
        if (crackedConversions == null) crackedConversions = new LinkedHashMap<>();
    }

    private void compile() {
        breakable = BlockMatcher.parse(siegeBreakableBlocks);
        placeable = BlockMatcher.parse(siegePlaceableBlocks);
        cracked = new HashMap<>();
        crackedConversions.forEach((from, to) -> {
            Block f = lookup(from);
            Block t = lookup(to);
            if (f != null && t != null) cracked.put(f, t);
            else LOGGER.warn("Ignoring crackedConversions entry {} -> {}", from, to);
        });
    }

    @Nullable
    private static Block lookup(String id) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        return rl == null ? null : BuiltInRegistries.BLOCK.getOptional(rl).orElse(null);
    }

    /** A set of exact blocks plus block tags. */
    public static final class BlockMatcher {
        private final Set<Block> blocks = new HashSet<>();
        private final List<TagKey<Block>> tags = new ArrayList<>();

        static BlockMatcher parse(Collection<String> entries) {
            BlockMatcher m = new BlockMatcher();
            for (String e : entries) {
                if (e.startsWith("#")) {
                    ResourceLocation rl = ResourceLocation.tryParse(e.substring(1));
                    if (rl != null) m.tags.add(TagKey.create(Registries.BLOCK, rl));
                    else LOGGER.warn("Invalid block tag '{}'", e);
                } else {
                    Block b = lookup(e);
                    if (b != null) m.blocks.add(b);
                    else LOGGER.warn("Unknown block '{}'", e);
                }
            }
            return m;
        }

        public boolean matches(BlockState state) {
            if (blocks.contains(state.getBlock())) return true;
            for (TagKey<Block> t : tags) if (state.is(t)) return true;
            return false;
        }
    }
}
