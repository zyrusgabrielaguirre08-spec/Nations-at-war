package com.example.nationsatwar.mixin;

import com.example.nationsatwar.protection.ProtectionListener;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fabric API has no explosion event, so this is the one mixin. After the explosion has computed which blocks it
 * will destroy ({@code explode()} fills {@code toBlow}) and before {@code finalizeExplosion()} removes them, we
 * strip anything inside a protected claim. Targets the 1.21.1 {@code Explosion} class
 * (1.21.2+ moved this logic to {@code ServerExplosion}).
 */
@Mixin(Explosion.class)
public abstract class ExplosionMixin {
    @Shadow @Final private Level level;

    @Inject(method = "explode", at = @At("TAIL"))
    private void nationsatwar$protectClaims(CallbackInfo ci) {
        if (this.level.isClientSide()) return;
        Explosion self = (Explosion) (Object) this;
        ProtectionListener.filterExplosion(this.level, self.getIndirectSourceEntity(), self.getToBlow());
    }
}
