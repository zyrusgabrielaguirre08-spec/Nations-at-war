package com.example.nationsatwar.data;

import com.example.nationsatwar.NationsAtWarMod;
import com.example.nationsatwar.NationsConfig;
import com.example.nationsatwar.war.WarManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AbstractBannerBlock;
import net.minecraft.world.level.storage.LevelResource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Global state + persistence.
 *
 * <ul>
 *   <li>Source of truth (persisted): nations, player data, wars.</li>
 *   <li>Derived runtime indexes (rebuilt on load, never persisted): name index and the chunk-owner map.</li>
 *   <li>The chunk-owner map is a primitive {@code Long2ObjectOpenHashMap} keyed by {@link ChunkPos#toLong()}:
 *       O(1), no allocation per lookup, which matters because it is queried on every block action.</li>
 * </ul>
 * All access must happen on the server thread.
 */
public final class NationDataManager {
    private static final Logger LOGGER = LogManager.getLogger("NationsAtWar/Data");
    private static final Pattern VALID_NAME = Pattern.compile("[A-Za-z0-9_]+");
    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .registerTypeAdapter(ChunkPos.class, new ChunkPosAdapter())
            .create();

    private static NationDataManager instance;

    @Nullable
    public static NationDataManager get() { return instance; }

    public static void init(MinecraftServer server) {
        instance = new NationDataManager(server);
        instance.load();
    }

    public static void release() { instance = null; }

    /** Thrown for every expected, user-facing failure (shown to the player as a red message). */
    public static final class NationException extends Exception {
        public NationException(String message) { super(message); }
    }

    private static final class SaveData {
        int version = 1;
        Map<UUID, Nation> nations = new HashMap<>();
        Map<UUID, PlayerData> players = new HashMap<>();
        List<War> wars = new ArrayList<>();
    }

    private static final class ChunkPosAdapter implements JsonSerializer<ChunkPos>, JsonDeserializer<ChunkPos> {
        @Override
        public JsonElement serialize(ChunkPos src, Type type, JsonSerializationContext ctx) {
            return new JsonPrimitive(src.toLong());
        }

        @Override
        public ChunkPos deserialize(JsonElement json, Type type, JsonDeserializationContext ctx) throws JsonParseException {
            return new ChunkPos(json.getAsLong());
        }
    }

    private final MinecraftServer server;
    private final Path dataDir;
    private final Path dataFile;
    private final WarManager warManager;

    // persisted
    private final Map<UUID, Nation> nations = new HashMap<>();
    private final Map<UUID, PlayerData> players = new HashMap<>();
    private final List<War> wars = new ArrayList<>();

    // derived / transient
    private final Map<String, UUID> nameIndex = new HashMap<>();
    private final Long2ObjectOpenHashMap<String> chunkOwners = new Long2ObjectOpenHashMap<>();
    /** invited player -> (nation id -> expiry epoch ms) */
    private final Map<UUID, Map<UUID, Long>> invites = new HashMap<>();
    private final Set<UUID> bypassing = new HashSet<>();
    private boolean dirty;

    private NationDataManager(MinecraftServer server) {
        this.server = server;
        this.dataDir = server.getWorldPath(LevelResource.ROOT).resolve("data").resolve("nations_at_war");
        this.dataFile = dataDir.resolve("nations.json");
        this.warManager = new WarManager(this);
    }

    private static NationsConfig cfg() { return NationsAtWarMod.config(); }

    public MinecraftServer server() { return server; }
    public WarManager warManager() { return warManager; }
    public List<War> wars() { return wars; }

    // ================================================================== persistence

    public void markDirty() { dirty = true; }

    public void saveIfDirty() { if (dirty) save(); }

    public void load() {
        try {
            Files.createDirectories(dataDir);
        } catch (IOException e) {
            LOGGER.error("Could not create {}", dataDir, e);
            return;
        }
        if (!Files.exists(dataFile)) {
            LOGGER.info("No existing nation data at {}; starting fresh.", dataFile);
            return;
        }
        try (Reader r = Files.newBufferedReader(dataFile, StandardCharsets.UTF_8)) {
            SaveData sd = GSON.fromJson(r, SaveData.class);
            if (sd != null) {
                if (sd.nations != null) nations.putAll(sd.nations);
                if (sd.players != null) players.putAll(sd.players);
                if (sd.wars != null) wars.addAll(sd.wars);
            }
            rebuildIndexes();
            LOGGER.info("Loaded {} nations, {} players, {} wars.", nations.size(), players.size(), wars.size());
        } catch (IOException | JsonParseException e) {
            LOGGER.error("Failed to read {}. The file is being moved aside so it is not overwritten.", dataFile, e);
            nations.clear();
            players.clear();
            wars.clear();
            try {
                Files.move(dataFile, dataDir.resolve("nations.corrupt-" + System.currentTimeMillis() + ".json"));
            } catch (IOException moveErr) {
                LOGGER.error("Could not back up the corrupt data file", moveErr);
            }
        }
    }

    public void save() {
        SaveData sd = new SaveData();
        sd.nations = nations;
        sd.players = players;
        sd.wars = wars;
        Path tmp = dataDir.resolve("nations.json.tmp");
        try {
            Files.createDirectories(dataDir);
            Files.writeString(tmp, GSON.toJson(sd), StandardCharsets.UTF_8);
            try {
                Files.move(tmp, dataFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, dataFile, StandardCopyOption.REPLACE_EXISTING);
            }
            dirty = false;
        } catch (IOException e) {
            LOGGER.error("Failed to save nation data to {}", dataFile, e);
        }
    }

    private void rebuildIndexes() {
        nameIndex.clear();
        chunkOwners.clear();
        for (Nation n : nations.values()) {
            nameIndex.put(key(n.name), n.id);
            Iterator<ChunkPos> it = n.claimedChunks.iterator();
            while (it.hasNext()) {
                long k = it.next().toLong();
                if (chunkOwners.containsKey(k)) {
                    LOGGER.warn("Chunk {} claimed by both {} and {}; dropping it from {}.",
                            new ChunkPos(k), chunkOwners.get(k), n.name, n.name);
                    it.remove();
                } else {
                    chunkOwners.put(k, n.name);
                }
            }
        }
        for (PlayerData pd : players.values()) {
            if (pd.nationId != null && !nations.containsKey(pd.nationId)) pd.nationId = null;
        }
        wars.removeIf(w -> !nations.containsKey(w.attacker) || !nations.containsKey(w.defender));
    }

    // ================================================================== lookups (hot path)

    private static String key(String name) { return name.toLowerCase(Locale.ROOT); }

    public static long chunkKey(BlockPos pos) {
        return ChunkPos.asLong(pos.getX() >> 4, pos.getZ() >> 4);
    }

    public boolean hasAnyClaims() { return !chunkOwners.isEmpty(); }

    /** Claims only exist in the Overworld. Returns the owning nation or null. */
    @Nullable
    public Nation getNationAt(Level level, BlockPos pos) {
        if (chunkOwners.isEmpty() || !Level.OVERWORLD.equals(level.dimension())) return null;
        String owner = chunkOwners.get(chunkKey(pos));
        return owner == null ? null : getNationByName(owner);
    }

    @Nullable
    public Nation getNation(UUID id) { return nations.get(id); }

    @Nullable
    public Nation getNationByName(String name) {
        UUID id = nameIndex.get(key(name));
        return id == null ? null : nations.get(id);
    }

    @Nullable
    public Nation getNationOf(UUID player) {
        PlayerData pd = players.get(player);
        return pd == null || pd.nationId == null ? null : nations.get(pd.nationId);
    }

    public Collection<Nation> nations() { return Collections.unmodifiableCollection(nations.values()); }

    public List<String> nationNames() {
        List<String> out = new ArrayList<>(nations.size());
        for (Nation n : nations.values()) out.add(n.name);
        return out;
    }

    public PlayerData getPlayerData(UUID uuid) {
        return players.computeIfAbsent(uuid, u -> {
            PlayerData pd = new PlayerData();
            pd.balance = cfg().startingBalance;
            markDirty();
            return pd;
        });
    }

    public void touchPlayer(ServerPlayer p) {
        PlayerData pd = getPlayerData(p.getUUID());
        String n = p.getGameProfile().getName();
        if (!n.equals(pd.lastKnownName)) {
            pd.lastKnownName = n;
            markDirty();
        }
    }

    public String nameOf(UUID player) {
        PlayerData pd = players.get(player);
        return pd == null || pd.lastKnownName.isEmpty() ? player.toString().substring(0, 8) : pd.lastKnownName;
    }

    public boolean toggleBypass(UUID player) {
        if (!bypassing.remove(player)) {
            bypassing.add(player);
            return true;
        }
        return false;
    }

    public boolean isBypassing(UUID player) { return bypassing.contains(player); }

    // ================================================================== guards

    public Nation requireNationOf(ServerPlayer p) throws NationException {
        Nation n = getNationOf(p.getUUID());
        if (n == null) throw new NationException("You are not in a nation.");
        return n;
    }

    public void requireOwner(Nation n, ServerPlayer p) throws NationException {
        if (!n.owner.equals(p.getUUID())) throw new NationException("Only the nation's owner can do that.");
    }

    public Nation requireNationByName(String name) throws NationException {
        Nation n = getNationByName(name);
        if (n == null) throw new NationException("No nation named '" + name + "'.");
        return n;
    }

    // ================================================================== nation lifecycle

    public Nation createNation(ServerPlayer p, String name) throws NationException {
        NationsConfig c = cfg();
        PlayerData pd = getPlayerData(p.getUUID());
        if (getNationOf(p.getUUID()) != null) throw new NationException("You are already in a nation.");
        if (name.length() < c.minNameLength || name.length() > c.maxNameLength || !VALID_NAME.matcher(name).matches()) {
            throw new NationException("Names must be " + c.minNameLength + "-" + c.maxNameLength
                    + " characters of letters, digits or underscores.");
        }
        if (nameIndex.containsKey(key(name))) throw new NationException("That name is already taken.");
        if (pd.balance < c.creationFee) {
            throw new NationException("Founding a nation costs " + money(c.creationFee)
                    + " but you only have " + money(pd.balance) + ".");
        }
        pd.balance = round2(pd.balance - c.creationFee);
        Nation n = new Nation(name, p.getUUID());
        nations.put(n.id, n);
        nameIndex.put(key(name), n.id);
        pd.nationId = n.id;
        markDirty();
        LOGGER.info("{} founded nation {}", p.getGameProfile().getName(), name);
        return n;
    }

    public void disbandNation(Nation n, boolean refundOwner) {
        for (War w : new ArrayList<>(wars)) if (w.involves(n.id)) wars.remove(w);
        for (ChunkPos c : n.claimedChunks) chunkOwners.remove(c.toLong());
        for (Nation other : nations.values()) {
            other.allies.remove(n.name);
            other.enemies.remove(n.name);
        }
        for (UUID m : n.members) {
            PlayerData pd = players.get(m);
            if (pd != null) pd.nationId = null;
        }
        if (refundOwner) getPlayerData(n.owner).balance = round2(getPlayerData(n.owner).balance + n.balance);
        nations.remove(n.id);
        nameIndex.remove(key(n.name));
        markDirty();
        LOGGER.info("Nation {} disbanded", n.name);
    }

    public void invite(ServerPlayer owner, ServerPlayer target) throws NationException {
        Nation n = requireNationOf(owner);
        requireOwner(n, owner);
        if (getNationOf(target.getUUID()) != null) throw new NationException(target.getGameProfile().getName() + " is already in a nation.");
        long expiry = System.currentTimeMillis() + cfg().inviteExpirySeconds * 1000L;
        invites.computeIfAbsent(target.getUUID(), k -> new HashMap<>()).put(n.id, expiry);
    }

    public Nation join(ServerPlayer p, String nationName) throws NationException {
        if (getNationOf(p.getUUID()) != null) throw new NationException("You are already in a nation.");
        Nation n = requireNationByName(nationName);
        Map<UUID, Long> mine = invites.get(p.getUUID());
        Long expiry = mine == null ? null : mine.get(n.id);
        if (expiry == null || expiry < System.currentTimeMillis()) {
            throw new NationException("You have no valid invitation from " + n.name + ".");
        }
        mine.remove(n.id);
        n.members.add(p.getUUID());
        getPlayerData(p.getUUID()).nationId = n.id;
        markDirty();
        return n;
    }

    public void leave(ServerPlayer p) throws NationException {
        Nation n = requireNationOf(p);
        if (n.owner.equals(p.getUUID())) throw new NationException("Owners can't leave. Use /nation disband instead.");
        n.members.remove(p.getUUID());
        getPlayerData(p.getUUID()).nationId = null;
        markDirty();
    }

    // ================================================================== claims

    public int maxClaims(Nation n) {
        return cfg().baseMaxClaims + cfg().extraClaimsPerMember * n.members.size();
    }

    public void claimChunk(ServerPlayer p, ChunkPos pos) throws NationException {
        Nation n = requireNationOf(p);
        requireOwner(n, p);
        if (!Level.OVERWORLD.equals(p.level().dimension())) throw new NationException("You can only claim land in the Overworld.");
        long k = pos.toLong();
        String existing = chunkOwners.get(k);
        if (existing != null) {
            throw new NationException(existing.equalsIgnoreCase(n.name)
                    ? "Your nation already owns this chunk."
                    : "This chunk is already claimed by " + existing + ".");
        }
        if (n.claimedChunks.size() >= maxClaims(n)) {
            throw new NationException("Claim limit reached (" + maxClaims(n) + "). More members raise the limit.");
        }
        if (cfg().requireAdjacentClaims && !n.claimedChunks.isEmpty() && !touchesTerritory(n, pos)) {
            throw new NationException("New claims must be adjacent to your existing territory.");
        }
        n.claimedChunks.add(pos);
        chunkOwners.put(k, n.name);
        markDirty();
    }

    public void unclaimChunk(ServerPlayer p, ChunkPos pos) throws NationException {
        Nation n = requireNationOf(p);
        requireOwner(n, p);
        String owner = chunkOwners.get(pos.toLong());
        if (owner == null || !owner.equalsIgnoreCase(n.name)) throw new NationException("Your nation doesn't own this chunk.");
        removeChunk(n, pos);
    }

    private void removeChunk(Nation n, ChunkPos pos) {
        n.claimedChunks.remove(pos);
        chunkOwners.remove(pos.toLong());
        if (n.bannerPos != null && ChunkPos.asLong(BlockPos.of(n.bannerPos).getX() >> 4, BlockPos.of(n.bannerPos).getZ() >> 4) == pos.toLong()) {
            n.bannerPos = null;
        }
        markDirty();
    }

    /** Moves a chunk between nations (used for war reparations). */
    public void transferChunk(ChunkPos pos, Nation from, Nation to) {
        removeChunk(from, pos);
        to.claimedChunks.add(pos);
        chunkOwners.put(pos.toLong(), to.name);
        markDirty();
    }

    private boolean touchesTerritory(Nation n, ChunkPos p) {
        return n.claimedChunks.contains(new ChunkPos(p.x + 1, p.z))
                || n.claimedChunks.contains(new ChunkPos(p.x - 1, p.z))
                || n.claimedChunks.contains(new ChunkPos(p.x, p.z + 1))
                || n.claimedChunks.contains(new ChunkPos(p.x, p.z - 1));
    }

    public void setBanner(ServerPlayer p, BlockPos pos) throws NationException {
        Nation n = requireNationOf(p);
        requireOwner(n, p);
        if (!(p.level().getBlockState(pos).getBlock() instanceof AbstractBannerBlock)) {
            throw new NationException("Look at a banner block (within 5 blocks).");
        }
        if (getNationAt(p.level(), pos) != n) throw new NationException("The banner must be inside your own claims.");
        n.bannerPos = pos.asLong();
        markDirty();
    }

    // ================================================================== diplomacy & economy

    /** Alliances are mutual. Returns true if the nations are now allied, false if the alliance was dissolved. */
    public boolean toggleAlly(ServerPlayer p, String targetName) throws NationException {
        Nation me = requireNationOf(p);
        requireOwner(me, p);
        Nation target = requireNationByName(targetName);
        if (me == target) throw new NationException("You can't ally your own nation.");
        if (warManager.findWar(me.id, target.id) != null) throw new NationException("You can't ally a nation you are at war with.");
        boolean allied;
        if (me.allies.contains(target.name)) {
            me.allies.remove(target.name);
            target.allies.remove(me.name);
            allied = false;
        } else {
            me.allies.add(target.name);
            target.allies.add(me.name);
            allied = true;
        }
        markDirty();
        return allied;
    }

    public void deposit(ServerPlayer p, double amount) throws NationException {
        Nation n = requireNationOf(p);
        PlayerData pd = getPlayerData(p.getUUID());
        amount = checkAmount(amount);
        if (pd.balance < amount) throw new NationException("You only have " + money(pd.balance) + ".");
        pd.balance = round2(pd.balance - amount);
        n.balance = round2(n.balance + amount);
        markDirty();
    }

    public void withdraw(ServerPlayer p, double amount) throws NationException {
        Nation n = requireNationOf(p);
        requireOwner(n, p);
        amount = checkAmount(amount);
        if (n.balance < amount) throw new NationException("The nation bank only holds " + money(n.balance) + ".");
        n.balance = round2(n.balance - amount);
        PlayerData pd = getPlayerData(p.getUUID());
        pd.balance = round2(pd.balance + amount);
        markDirty();
    }

    public void giveMoney(UUID player, double amount) {
        PlayerData pd = getPlayerData(player);
        pd.balance = round2(pd.balance + amount);
        markDirty();
    }

    private static double checkAmount(double a) throws NationException {
        a = round2(a);
        if (!Double.isFinite(a) || a <= 0) throw new NationException("Amount must be positive.");
        return a;
    }

    public static double round2(double v) { return Math.round(v * 100.0) / 100.0; }

    public static String money(double v) { return String.format(Locale.ROOT, "%,.2f", v); }

    // ================================================================== messaging

    public void broadcast(Nation n, Component msg) {
        for (UUID m : n.members) {
            ServerPlayer sp = server.getPlayerList().getPlayer(m);
            if (sp != null) sp.sendSystemMessage(msg);
        }
    }

    public void broadcastAll(Component msg) {
        server.getPlayerList().broadcastSystemMessage(msg, false);
    }

    public static Component info(String s) { return Component.literal(s).withStyle(ChatFormatting.AQUA); }
}
