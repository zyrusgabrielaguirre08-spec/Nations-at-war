package com.example.nationsatwar.protection;

import com.example.nationsatwar.NationsAtWarMod;
import com.example.nationsatwar.NationsConfig;
import com.example.nationsatwar.data.Nation;
import com.example.nationsatwar.data.NationDataManager;
import com.example.nationsatwar.war.WarManager;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.FireChargeItem;
import net.minecraft.world.item.FlintAndSteelItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AbstractBannerBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Land protection and combat gating, built on Fabric API callbacks (no per-action mixins needed).
 * Every handler starts with a cheap "are there any claims?" / "is this chunk claimed?" fast path.
 * Only {@link #filterExplosion} is invoked from a mixin (Fabric API has no explosion event).
 */
public final class ProtectionListener {
    private ProtectionListener() {}

    private static NationsConfig cfg() { return NationsAtWarMod.config(); }

    public static void register() {
        PlayerBlockBreakEvents.BEFORE.register(ProtectionListener::onBlockBreak);
        UseBlockCallback.EVENT.register(ProtectionListener::onUseBlock);
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(ProtectionListener::allowDamage);
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            NationDataManager data = NationDataManager.get();
            if (data != null && entity instanceof ServerPlayer victim
                    && source.getEntity() instanceof ServerPlayer killer && killer != victim) {
                data.warManager().onPlayerKill(killer, victim);
            }
        });
    }

    // ================================================================== access helpers

    /** Member of the owning nation (or an ally, if configured), or an admin with bypass enabled. */
    private static boolean isTrusted(NationDataManager data, ServerPlayer sp, Nation owner) {
        if (data.isBypassing(sp.getUUID())) return true;
        Nation mine = data.getNationOf(sp.getUUID());
        if (mine == null) return false;
        if (mine.id.equals(owner.id)) return true;
        return cfg().alliesCanInteract && owner.allies.contains(mine.name);
    }

    private static boolean atWarWith(NationDataManager data, ServerPlayer sp, Nation owner) {
        Nation mine = data.getNationOf(sp.getUUID());
        return mine != null && data.warManager().isActiveWar(mine.id, owner.id);
    }

    private static void deny(ServerPlayer sp, String msg) {
        sp.displayClientMessage(Component.literal(msg).withStyle(ChatFormatting.RED), true);
    }

    private static String ownedBy(Nation owner) { return "This land belongs to " + owner.name + "."; }

    // ================================================================== block breaking

    private static boolean onBlockBreak(Level level, Player player, BlockPos pos, BlockState state, @Nullable BlockEntity be) {
        if (level.isClientSide() || !(player instanceof ServerPlayer sp)) return true;
        NationDataManager data = NationDataManager.get();
        if (data == null || !data.hasAnyClaims()) return true;
        Nation owner = data.getNationAt(level, pos);
        if (owner == null) return true;
        if (isTrusted(data, sp, owner)) return true;

        if (atWarWith(data, sp, owner)) {
            Nation mine = data.getNationOf(sp.getUUID());
            // Banner capture ends the war; the banner itself is left standing.
            if (state.getBlock() instanceof AbstractBannerBlock
                    && data.warManager().tryCaptureBanner(sp, mine, owner, pos)) {
                return false;
            }
            return siegeBreak((ServerLevel) level, sp, pos, state);
        }
        deny(sp, ownedBy(owner));
        return false;
    }

    /**
     * Controlled destruction during war. Always returns false (the vanilla break is cancelled) because we either
     * performed our own no-drop removal / cracking, or refused.
     */
    private static boolean siegeBreak(ServerLevel level, ServerPlayer sp, BlockPos pos, BlockState state) {
        NationsConfig c = cfg();
        if (!c.warAllowSiegeBreaking) {
            deny(sp, "Siege breaking is disabled.");
            return false;
        }
        Block cracked = c.crackedVariantOf(state.getBlock());
        if (cracked != null) {
            level.setBlock(pos, cracked.defaultBlockState(), Block.UPDATE_ALL);
            level.levelEvent(2001, pos, Block.getId(state)); // 2001 = block-break particles + sound
            return false;
        }
        if (c.isSiegeBreakable(state)) {
            level.destroyBlock(pos, false, sp); // dropResource=false -> no item drops
            return false;
        }
        deny(sp, "That block can't be broken during a siege. Use TNT, or break doors and cracked blocks.");
        return false;
    }

    // ================================================================== interaction & placement

    private static InteractionResult onUseBlock(Player player, Level level, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide() || !(player instanceof ServerPlayer sp) || sp.isSpectator()) return InteractionResult.PASS;
        NationDataManager data = NationDataManager.get();
        if (data == null || !data.hasAnyClaims()) return InteractionResult.PASS;

        BlockPos clicked = hit.getBlockPos();
        BlockState clickedState = level.getBlockState(clicked);
        ItemStack held = player.getItemInHand(hand);
        Item item = held.getItem();

        // 1) Using the clicked block: containers and switches.
        Nation clickedOwner = data.getNationAt(level, clicked);
        if (clickedOwner != null) {
            BlockEntity be = level.getBlockEntity(clicked);
            boolean container = be instanceof Container;
            boolean sw = isSwitch(clickedState);
            if ((container || sw) && !isTrusted(data, sp, clickedOwner)) {
                boolean warAllows = atWarWith(data, sp, clickedOwner)
                        && (container ? cfg().warAllowContainerAccess : cfg().warAllowSwitchInteraction);
                if (!warAllows) {
                    deny(sp, ownedBy(clickedOwner));
                    return InteractionResult.FAIL;
                }
            }
        }

        // 2) Placing blocks / fluids / fire next to or onto the clicked block.
        if (item instanceof BlockItem || item instanceof BucketItem) {
            BlockPlaceContext ctx = new BlockPlaceContext(player, hand, held, hit);
            BlockPos placePos = ctx.getClickedPos();
            Nation placeOwner = data.getNationAt(level, placePos);
            if (placeOwner != null && !isTrusted(data, sp, placeOwner)) {
                boolean warAllows = atWarWith(data, sp, placeOwner)
                        && item instanceof BlockItem bi
                        && cfg().isSiegePlaceable(bi.getBlock().defaultBlockState());
                if (!warAllows) {
                    deny(sp, ownedBy(placeOwner));
                    return InteractionResult.FAIL;
                }
            }
        } else if ((item instanceof FlintAndSteelItem || item instanceof FireChargeItem) && clickedOwner != null
                && !isTrusted(data, sp, clickedOwner)) {
            // Only allow lighting TNT, and only during war.
            boolean warAllows = atWarWith(data, sp, clickedOwner) && clickedState.is(Blocks.TNT);
            if (!warAllows) {
                deny(sp, ownedBy(clickedOwner));
                return InteractionResult.FAIL;
            }
        }
        return InteractionResult.PASS;
    }

    private static boolean isSwitch(BlockState s) {
        Block b = s.getBlock();
        return b instanceof DoorBlock || b instanceof TrapDoorBlock || b instanceof FenceGateBlock
                || b instanceof ButtonBlock || b instanceof LeverBlock;
    }

    // ================================================================== explosions (called from ExplosionMixin)

    /**
     * Removes protected blocks from an explosion's destruction list. A block in a claim is only destroyed if the
     * explosion was started by (a) a member of the owning nation or (b) a player whose nation is in an active war
     * with the owner, with {@code warExplosionsEnabled} on. Banner blocks are always shielded.
     */
    public static void filterExplosion(Level level, @Nullable Entity indirectSource, List<BlockPos> toBlow) {
        NationDataManager data = NationDataManager.get();
        if (data == null || !data.hasAnyClaims() || toBlow.isEmpty()) return;
        final Nation igniterNation = indirectSource instanceof ServerPlayer sp ? data.getNationOf(sp.getUUID()) : null;
        final boolean warBlasts = cfg().warExplosionsEnabled;
        final WarManager wars = data.warManager();

        toBlow.removeIf(pos -> {
            Nation owner = data.getNationAt(level, pos);
            if (owner == null) return false;                                   // wilderness: vanilla behaviour
            if (owner.bannerPos != null && owner.bannerPos == pos.asLong()) return true; // banners are shielded
            if (igniterNation == null) return true;                            // creepers, redstone TNT, ...
            if (igniterNation.id.equals(owner.id)) return false;               // your own land
            return !(warBlasts && wars.isActiveWar(igniterNation.id, owner.id));
        });
    }

    // ================================================================== PvP rules

    private static boolean allowDamage(net.minecraft.world.entity.LivingEntity entity,
                                       net.minecraft.world.damagesource.DamageSource source, float amount) {
        if (!(entity instanceof ServerPlayer victim) || !(source.getEntity() instanceof ServerPlayer attacker) || attacker == victim) {
            return true;
        }
        NationDataManager data = NationDataManager.get();
        if (data == null) return true;
        Nation a = data.getNationOf(attacker.getUUID());
        Nation v = data.getNationOf(victim.getUUID());

        boolean sameOrAllied = a != null && v != null && (a.id.equals(v.id) || a.allies.contains(v.name));
        if (sameOrAllied && !cfg().friendlyFire) return false;
        if (cfg().pvpOnlyBetweenWarringNations) {
            return a != null && v != null && data.warManager().isActiveWar(a.id, v.id);
        }
        return true;
    }
}
