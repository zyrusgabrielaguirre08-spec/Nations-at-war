package com.example.nationsatwar.data;

import net.minecraft.world.level.ChunkPos;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/** A nation. Plain mutable data holder (Gson-serialised); all logic lives in {@link NationDataManager}. */
public final class Nation {
    public UUID id = UUID.randomUUID();
    public String name = "";
    public UUID owner;
    public Set<UUID> members = new LinkedHashSet<>();
    public Set<ChunkPos> claimedChunks = new HashSet<>();
    public double balance;
    public Set<String> allies = new LinkedHashSet<>();
    public Set<String> enemies = new LinkedHashSet<>();
    /** Packed BlockPos (BlockPos#asLong) of the capturable banner block, or null. */
    @Nullable
    public Long bannerPos;

    /** Required by Gson. */
    public Nation() {}

    public Nation(String name, UUID owner) {
        this.name = name;
        this.owner = owner;
        this.members.add(owner);
    }
}
