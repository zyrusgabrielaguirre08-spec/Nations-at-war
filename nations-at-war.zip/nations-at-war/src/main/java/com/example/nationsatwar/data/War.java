package com.example.nationsatwar.data;

import java.util.UUID;

/** A declared war between two nations. Ended wars are removed from the list. */
public final class War {
    public enum State { PENDING, ACTIVE }

    public UUID attacker;
    public UUID defender;
    public State state = State.PENDING;
    public long declaredAtMs;
    public long startsAtMs;
    public int attackerScore;
    public int defenderScore;

    /** Required by Gson. */
    public War() {}

    public War(UUID attacker, UUID defender, long declaredAtMs, long startsAtMs) {
        this.attacker = attacker;
        this.defender = defender;
        this.declaredAtMs = declaredAtMs;
        this.startsAtMs = startsAtMs;
    }

    public boolean involves(UUID nation) {
        return attacker.equals(nation) || defender.equals(nation);
    }

    public boolean isBetween(UUID a, UUID b) {
        return (attacker.equals(a) && defender.equals(b)) || (attacker.equals(b) && defender.equals(a));
    }

    public UUID other(UUID nation) {
        return attacker.equals(nation) ? defender : attacker;
    }
}
