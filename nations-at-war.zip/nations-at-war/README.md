# Nations At War (Fabric, Minecraft 1.21.1)

Server-side nations, chunk claiming, a virtual economy and a siege/war framework.
Vanilla clients can connect to a dedicated server running it (no custom registries or packets).

## Target / assumptions
- Fabric Loader 0.16.x, Fabric API for 1.21.1, Java 21, **Mojang (official) mappings**.
- Package `com.example.nationsatwar` - rename to your own group id.
- **Not yet compiled or run.** Class/method names were written against 1.21.1 Mojang mappings from memory.
  Likeliest spots to need a tweak: `ExplosionMixin` (`Explosion#explode`, `getToBlow`, `level` field),
  `BlockPlaceContext#getClickedPos`, `AbstractBannerBlock`, and the Fabric API version in `gradle.properties`.
- This code is pinned to 1.21.1. On 1.21.2+ explosion logic moved to `ServerExplosion` (mixin must change) and
  `hasPermission(int)` was replaced by the new permission system on later versions.

## Build
    ./gradlew build        # jar in build/libs/
    ./gradlew runServer    # dev server

## Files
| File | Role |
|---|---|
| `NationsAtWarMod` | Entry point: config, lifecycle load/save, 1 s war tick, 5 min autosave, registration |
| `NationsConfig` | `config/nations_at_war.json` (fees, limits, war rules, siege block lists) |
| `data/NationDataManager` | Global state, JSON persistence, lookups, nation/claim/economy logic |
| `data/Nation`, `PlayerData`, `War` | Plain data holders |
| `war/WarManager` | War state machine (PENDING -> ACTIVE -> resolved), scoring, banner capture, reparations |
| `command/ModCommands` | Brigadier tree under `/nation` |
| `protection/ProtectionListener` | Break / place / interact protection, siege rules, PvP rules, explosion filter |
| `mixin/ExplosionMixin` | Only mixin: hands the explosion block list to `ProtectionListener.filterExplosion` |

## Persistence
`<world>/data/nations_at_war/nations.json` (atomic write via temp file + move, autosave when dirty, save on stop).
Persisted: nations, player data, wars. The name index and the chunk-owner map are **rebuilt on load**
(so they can never disagree with the nations' own chunk sets). A corrupt file is moved aside, never overwritten.

## Commands (level 0 unless noted)
    /nation create <name>        /nation join <name>        /nation leave
    /nation invite <player>      /nation disband            /nation info [name]
    /nation claim                /nation unclaim            /nation setbanner (look at a banner)
    /nation ally <nation>        toggles a mutual alliance
    /nation enemy <nation>       declares war (countdown); toggle again while PENDING to withdraw
    /nation surrender            /nation deposit <amt>      /nation withdraw <amt>
    /nation admin bypass | reload | give <player> <amt> | disband <nation> | endwar <a> <b>     (level 2)

Owner-only: invite, claim, unclaim, setbanner, ally, enemy, surrender, withdraw, disband.

## War rules (all configurable)
1. `/nation enemy X` creates a PENDING war; after `warWarningSeconds` (default 24 h, wall-clock) it turns ACTIVE.
2. While ACTIVE: opposing members can fight; kills score; first to `warScoreToWin` wins, or whoever breaks the
   enemy's registered banner wins immediately.
3. Attackers cannot freely grief. In enemy claims they may only:
   - break blocks in `siegeBreakableBlocks` (removed with **no drops**),
   - "crack" blocks listed in `crackedConversions` (stone bricks -> cracked stone bricks, ...),
   - place blocks in `siegePlaceableBlocks` (TNT, ladders, scaffolding) and light TNT,
   - use doors/levers (`warAllowSwitchInteraction`); chests stay locked (`warAllowContainerAccess=false`),
   - destroy blocks with TNT they ignited (`warExplosionsEnabled`). Banners are shielded from explosions.
4. Winner receives `warLootPercent` of the loser's bank plus `warSurrenderChunks` chunks (those nearest the winner).

## Design decisions worth knowing
- Claims are **Overworld only** (the spec keys claims by ChunkPos alone, with no dimension).
- Chunk owner map is a fastutil `Long2ObjectOpenHashMap` keyed by `ChunkPos.toLong()`: O(1), no per-lookup allocation.
- Player wallet (`PlayerData.balance`) funds the creation fee and deposits. Seed it with `startingBalance`, or hook your
  own economy mod / `/nation admin give`.
- Nations can't be renamed (allies/enemies are stored by name, per the spec).
- Everything runs on the server thread; there is no locking.

## Not covered yet (ideas for next iteration)
Fluid flow, pistons, fire spread, and entity-modifying actions (item frames, armor stands, boats) into/out of claims;
claim visualisation / entering-leaving messages; non-Overworld dimensions; role ranks beyond owner/member.
